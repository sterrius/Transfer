using Asp.Versioning;
using Microsoft.AspNetCore.Mvc;

namespace Versioning.API.Controllers.V2;

[ApiVersion("2.0")]
[Route("api/v{version:apiVersion}/[controller]")]
[ApiController]
public class WeatherForecastController : ControllerBase
{
    // only responds to /v1 because of the ApiVersion tag on the Controller
    [HttpPost(Name = "CreateWeatherForecast")]
    public IActionResult Create()
    {
        return Ok("Create (version 2)");
    }
}
