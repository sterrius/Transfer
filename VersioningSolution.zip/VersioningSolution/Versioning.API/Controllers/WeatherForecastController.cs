using Asp.Versioning;
using Microsoft.AspNetCore.Mvc;

namespace Versioning.API.Controllers;

[ApiVersion("1.0")]
[Route("api/v{version:apiVersion}/[controller]")]
[ApiController]
public class WeatherForecastController : ControllerBase
{
    private static readonly string[] Summaries =
    [
        "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
    ];

    // /v1 and /v2 both execute this endpoint
    [ApiVersion("2.0")]
    [ApiVersion("1.0")]
    [HttpGet(Name = "GetWeatherForecast")]
    public IEnumerable<WeatherForecast> Get()
    {
        return Enumerable.Range(1, 5).Select(index => new WeatherForecast
        {
            Date = DateOnly.FromDateTime(DateTime.Now.AddDays(index)),
            TemperatureC = Random.Shared.Next(-20, 55),
            Summary = Summaries[Random.Shared.Next(Summaries.Length)]
        })
        .ToArray();
    }

    // only responds to /v1 because of the ApiVersion tag on the Controller
    [HttpPost(Name = "CreateWeatherForecast")]
    public IActionResult Create()
    {
        return Ok("Create (version 1)");
    }
}
