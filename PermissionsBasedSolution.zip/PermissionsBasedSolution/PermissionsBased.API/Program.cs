
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;

namespace PermissionsBased.API;

public class Program
{
    public static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        builder.Services.AddAuthorization(options =>
        {
            options.DefaultPolicy = new AuthorizationPolicyBuilder()
                .RequireAuthenticatedUser()
                .Build();
        });

        AuthenticationBuilder authenticationBuilder = builder.Services.AddAuthentication();
        authenticationBuilder.AddJwtBearer("Bearer", options =>
        {
            options.Authority = "https://demo.identityserver.io";
        });

        AuthorizationBuilder authorizationBuilder = builder.Services.AddAuthorizationBuilder();
        authorizationBuilder.AddPolicy("WeatherForecast.Get", policy =>
        {
            policy.AddRequirements(new PhoenixAuthorizationRequirement(WeatherForecastAuthArrays.GetPermissions, WeatherForecastAuthArrays.GetRoles));
        });

        builder.Services.AddSingleton<IAuthorizationHandler, PhoenixAuthorizationHandler>();

        // Add services to the container.
        PermissionsCache permissionsCache = new PermissionsCache();
        builder.Services.AddSingleton<IPermissionsCache>(permissionsCache);

        builder.Services.AddControllers();
        // Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
        builder.Services.AddOpenApi();

        var app = builder.Build();

        // Configure the HTTP request pipeline.
        if (app.Environment.IsDevelopment())
        {
            app.MapOpenApi();
        }

        if (app.Environment.IsDevelopment())
        {
            app.Use(async (context, next) =>
            {
                var claims = new[]
                {
                    new Claim(ClaimTypes.NameIdentifier, "dev-user"),
                    new Claim(ClaimTypes.Name, "Dev User"),
                    new Claim(ClaimTypes.Role, "Admin")
                };

                var identity = new ClaimsIdentity(claims, "DevBypass");
                context.User = new ClaimsPrincipal(identity);

                permissionsCache.AddPermission("Dev User", "AX.ReadOnly");

                await next();
            });
        }

        app.UseHttpsRedirection();

        app.UseAuthentication();

        app.UseAuthorization();

        app.MapControllers();

        app.Run();
    }
}
