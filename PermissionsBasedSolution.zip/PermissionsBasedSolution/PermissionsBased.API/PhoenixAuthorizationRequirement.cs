﻿using Microsoft.AspNetCore.Authorization;

namespace PermissionsBased.API;

// Class representing a custom authorization requirement - Either a permission or a role is required for authorization (logic in the PhoenixAuthorizationHandler)
public class PhoenixAuthorizationRequirement : IAuthorizationRequirement
{
    public string[] Permissions { get; }

    public string[] Roles { get; }

    public PhoenixAuthorizationRequirement(string[] permissions, string[] roles)
    {
        Permissions = permissions;
        Roles = roles;
    }   
}
