﻿using Microsoft.AspNetCore.Authorization;

namespace PermissionsBased.API;

public class PhoenixAuthorizationHandler(IPermissionsCache _permissionsCache) : AuthorizationHandler<PhoenixAuthorizationRequirement>
{
    protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, PhoenixAuthorizationRequirement requirement)
    {
        if (context.User.Identity?.IsAuthenticated == true && IsUserAuthorized(context, requirement.Permissions, requirement.Roles))
        {
            context.Succeed(requirement);
        }
        else
        {
            context.Fail();
        }

        return Task.CompletedTask;
    }

    private bool IsUserAuthorized(AuthorizationHandlerContext context, string[] permissions, string[] roles)
    {
        if (_permissionsCache.HasPermission(context.User.Identity?.Name ?? string.Empty, permissions))
        {
            return true;
        }
        else
        {
            return roles.Any(context.User.IsInRole);
        }
    }
}
