﻿using System.Collections.Concurrent;

namespace PermissionsBased.API;

public interface IPermissionsCache
{
    public bool HasPermission(string userId, string[] permissions);

    public void AddPermission(string userId, string permission);
}

public class PermissionsCache : IPermissionsCache
{
    private ConcurrentDictionary<string, List<string>> _permissionsCache = new ConcurrentDictionary<string, List<string>>();

    public void AddPermission(string userId, string permission)
    {
        if (!_permissionsCache.ContainsKey(userId))
        {
            _permissionsCache.TryAdd(userId, new List<string>() { permission });
        }
        else
        {
            if (!_permissionsCache[userId].Contains(permission))
            {
                _permissionsCache[userId].Add(permission);
            }
        }
    }

    public bool HasPermission(string userId, string[] permissions)
    {
        if (_permissionsCache.ContainsKey(userId))
        {
            return permissions.Any(p => _permissionsCache[userId].Contains(p));
        }
        else
        {
            return false;
        }
    }
}
