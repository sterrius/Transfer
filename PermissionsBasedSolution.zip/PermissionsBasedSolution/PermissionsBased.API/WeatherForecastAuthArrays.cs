﻿namespace PermissionsBased.API;

public static class WeatherForecastAuthArrays
{
    #region Get

    public static readonly string[] GetPermissions = { "AX.ReadOnly", "AX.Admin" };
    public static readonly string[] GetRoles = { "Integration", "SuperAdmin" };

    #endregion
}
