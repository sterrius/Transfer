namespace MyApp.IDP;

public class Program
{
    public static void Main(string[] args)
    {
        Console.Title = "IdentityProvider";
        var builder = WebApplication.CreateBuilder(args);

        builder.Services.AddRazorPages();

        IIdentityServerBuilder isBuilder = builder.Services.AddIdentityServer()
            .AddTestUsers(IdentityServerHost.Pages.TestUsers.Users)
            .AddInMemoryIdentityResources(Config.IdentityResources)
            .AddInMemoryApiResources(Config.ApiResources)
            .AddInMemoryApiScopes(Config.ApiScopes)
            .AddInMemoryClients(Config.Clients);

        builder.Services.AddAuthentication();
        builder.Services.AddAuthorization();

        var app = builder.Build();

        app.UseStaticFiles();
        app.UseRouting();
        app.UseIdentityServer();
        app.UseAuthorization();

        app.MapRazorPages()
            .RequireAuthorization();

        app.Run();
    }
}
