﻿using Duende.IdentityServer.Models;

namespace MyApp.IDP;

public static class Config
{
    public static IEnumerable<IdentityResource> IdentityResources =>
    [
        new IdentityResources.OpenId(),
        new IdentityResources.Profile()
    ];

    public static IEnumerable<ApiScope> ApiScopes =>
        [
            new ApiScope("myapp.api")
        ];

    public static IEnumerable<ApiResource> ApiResources =>
        [
            new ApiResource("MyApp", "MyApp API")
            {
                Scopes = { "myapp.api" }
            }
        ];

    public static IEnumerable<Client> Clients =>
        [
            new Client // interactive client using code flow + pkce
            {
                ClientId = "MyApp",
                ClientSecrets = { new Secret("49C1A7E1-0C79-4A89-A3D6-A37998FB86B0".Sha256()) },
                AllowedGrantTypes = GrantTypes.Code,
                AllowOfflineAccess = true,
                RequirePkce = true,
                RedirectUris = { "https://localhost:7180/signin-oidc" },
                FrontChannelLogoutUri = "https://localhost:7180/signout-oidc",
                PostLogoutRedirectUris = { "https://localhost:7180/signout-callback-oidc" },
                AccessTokenLifetime = 1200, // 20 minutes
                AbsoluteRefreshTokenLifetime = 0, // sliding expiration
                RefreshTokenExpiration = TokenExpiration.Sliding,
                RefreshTokenUsage = TokenUsage.OneTimeOnly,
                SlidingRefreshTokenLifetime = 1260, // 21 minutes
                AllowedScopes = { "openid", "profile", "myapp.api", "offline_access" },
            }
        ];
}
