﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;

namespace MyApp.Backend;

public class BFFService
{
    public async Task LogIn(HttpContext context)
    {
        await context.ChallengeAsync(OpenIdConnectDefaults.AuthenticationScheme, new AuthenticationProperties
        {
            RedirectUri = "/"
        });
    }

    public async Task TokenLifetimeManagement(HttpContext httpContext)
    {
        if (DateTime.TryParse(await httpContext.GetTokenAsync("expires_at"), out DateTime expiriesAt)) // Token exists
        {
            if (httpContext.Session.GetString("CheckTime") == null || (DateTime.TryParse(httpContext.Session.GetString("CheckTime"), out DateTime parsedCheckTime) && parsedCheckTime < DateTime.Now.Subtract(TimeSpan.FromMinutes(5))))
            {
                // Check if the token is going to expire in 10 minutes or less. If it is, we need to refresh the token. This is done to ensure that the user is not logged out due to an expired token while they are still active in the application.
                if (expiriesAt < DateTime.Now.AddMinutes(10))
                {
                    var refreshToken = await httpContext.GetTokenAsync("refresh_token");

                    if (refreshToken != null)
                    {
                        HttpClient client = new HttpClient();

                        var response = await client.SendAsync(new HttpRequestMessage(HttpMethod.Post, "https://localhost:5001/connect/token")
                        {
                            Content = new FormUrlEncodedContent(new Dictionary<string, string>
                                {
                                    { "grant_type", "refresh_token" },
                                    { "client_id", "MyApp" },
                                    { "client_secret", "49C1A7E1-0C79-4A89-A3D6-A37998FB86B0" },
                                    { "refresh_token", refreshToken }
                                })
                        });

                        if (response.IsSuccessStatusCode)
                        {
                            TokenResponse? tokenResponse = await response.Content.ReadFromJsonAsync<TokenResponse>();
                            if (tokenResponse != null)
                            {
                                var expiresAt = DateTime.Now.AddSeconds(tokenResponse.Expires_In - 5);
                                var authProperties = new AuthenticationProperties();
                                authProperties.StoreTokens(new[]
                                {
                                    new AuthenticationToken { Name = "access_token", Value = tokenResponse.Access_Token },
                                    new AuthenticationToken { Name = "refresh_token", Value = tokenResponse.Refresh_Token },
                                    new AuthenticationToken { Name = "expires_at", Value = expiresAt.ToString("o") }
                                });

                                httpContext.Session.SetString("CheckTime", DateTime.Now.ToString("o"));
                                await httpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, httpContext.User, authProperties);
                            }
                            else // Token response is null, log out the user
                            {
                                await LogOut(httpContext);
                            }
                        }
                        else // Refresh token request failed, log out the user
                        {
                            await LogOut(httpContext);
                        }
                    }
                    else // Refresh token is null, log out the user
                    {
                        await LogOut(httpContext);
                    }
                }
            }
        }
        else // Token does not exist, challenge the user to log in
        {
            await LogIn(httpContext);
        }
    }

    public async Task LogOut(HttpContext context)
    {
        await context.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        await context.SignOutAsync(OpenIdConnectDefaults.AuthenticationScheme);
    }
}
