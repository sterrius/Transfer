using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using System.Net.Http.Headers;
using Yarp.ReverseProxy.Transforms;

namespace MyApp.Backend;

public class Program
{
    // The cookie is a session cookie - It's stored in memory and gets wiped when all browser windows are closed. The cookie is not stored on disk and is not persistent. The user will have to log in again when they open a new browser window.
    public static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        builder.Services.AddScoped<BFFService>();
        builder.Services.AddDistributedMemoryCache();
        builder.Services.AddSession(options =>
        {
            options.Cookie.Name = "__Host-MyAppSession";
            options.Cookie.SameSite = SameSiteMode.Strict;
            options.Cookie.SecurePolicy = CookieSecurePolicy.Always;
            options.Cookie.HttpOnly = true;
            options.Cookie.Path = "/";
        });

        builder.Services.AddReverseProxy()
            .LoadFromConfig(builder.Configuration.GetSection("ReverseProxy"))
            .AddTransforms(transformBuilderContext =>
            {
                transformBuilderContext.AddRequestTransform(async transformContext =>
                {
                    BFFService bffService = transformContext.HttpContext.RequestServices.GetRequiredService<BFFService>();
                    await bffService.TokenLifetimeManagement(transformContext.HttpContext);

                    // Only apply this transform to routes that require auth
                    if (string.Equals("Default", transformBuilderContext.Route.AuthorizationPolicy))
                    {
                        var accessToken = await transformContext.HttpContext.GetTokenAsync("access_token");

                        if (string.IsNullOrEmpty(accessToken))
                        {
                            transformContext.HttpContext.Response.StatusCode = 401;
                            return;
                        }

                        transformContext.ProxyRequest.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                    }
                });
            });

        builder.Services.AddAuthentication(options =>
        {
            options.DefaultAuthenticateScheme = CookieAuthenticationDefaults.AuthenticationScheme;
            options.DefaultChallengeScheme = OpenIdConnectDefaults.AuthenticationScheme;
        })
        .AddCookie(CookieAuthenticationDefaults.AuthenticationScheme, options =>
        {
            options.Cookie.Name = "__Host-MyAppCookie";
            options.Cookie.SameSite = SameSiteMode.Strict;
            options.Cookie.SecurePolicy = CookieSecurePolicy.Always;
            options.Cookie.HttpOnly = true;
            options.Cookie.Path = "/";
            options.SlidingExpiration = false;
        })
        .AddOpenIdConnect(OpenIdConnectDefaults.AuthenticationScheme, options =>
        {
            options.SignInScheme = CookieAuthenticationDefaults.AuthenticationScheme;
            options.Authority = "https://localhost:5001";
            options.ClientId = "MyApp";
            options.ClientSecret = "49C1A7E1-0C79-4A89-A3D6-A37998FB86B0";
            options.ResponseType = "code";
            options.Scope.Add("myapp.api");
            options.Scope.Add("offline_access");
            options.SaveTokens = true;
            options.SignedOutCallbackPath = "/signout-callback-oidc";
            options.SignedOutRedirectUri = "/goodbye";
        });

        var app = builder.Build();

        app.UseSession();
        app.UseAuthentication();
        app.UseAuthorization();
        app.MapReverseProxy();

        app.MapGet("/login", async (HttpContext context, BFFService bffService) =>
        {
            await bffService.LogIn(context);
        });

        app.MapGet("/logout", async (HttpContext context, BFFService bffService) =>
        {
            await bffService.LogOut(context);
        });

        app.MapGet("/signout-callback-oidc", () => Results.Ok());
        app.MapGet("/goodbye", () => Results.Content("<html><body><p>Goodbye!</p></body></html>", "text/html")); // Example non-authenticated post-logout page

        app.Run();
    }
}
